<?php
// 
$results = [
    // BRILLE:
    ['headline' => 'Ditt favorittprogram denne høsten er <strong>Brille</strong>',
    'description' => 'Brille er et humorbasert panelprogram som ledes med ustø hånd av veteran Harald Eia. Noen av landets morsomste komikere samles for å svare på tilsynelatende umulige spørsmål og oppgaver. Det eneste som er morsommere enn de svarene er for øvrig panelets rotete funderinger og bortforklaringer.'],

    // KJENDISKVELD MED MAGNUS DEVOLD:
    ['headline' => 'Ditt favorittprogram denne høsten er Kjendiskveld med Magnus Devold',
    'description' => 'Etter fire år som praktikant i I kveld med YLVIS får Magnus Devold endelig sitt eget humorprogram på TVNorge: Kjendiskveld med Magnus Devold. Han skal lage kjendisnyheter slik kun amerikanerne har laget dem til nå.'],

    // I KVELD MED YLVIS LIVE:
    ['headline' => 'Ditt favorittprogram denne høsten er I kveld med Ylvis Live',
    'description' => 'Brødrene Bård og Vegard Ylvisåker annonserte i fjor at 2015 ville bli et sabbatsår fra TV-skjermen. Nå har de ombestemt seg, og kommer likevel dansende ut på scenen igjen til høsten.'],

    // ADAM SØKER EVA:
    ['headline' => 'Ditt favorittprogram denne høsten er Adam søker Eva',
    'description' => 'Naken-dating på TV har vært en av de heiteste trendene i USA og Europa det siste året. I høst settes kropp i fokus når TVNorge inviterer norske, nakne og nysgjerrige single til en øde paradisøy'],

    // EN HELT VANLIG DAG:
    ['headline' => 'Ditt favorittprogram denne høsten er En helt vanlig dag',
    'description' => 'Hvor morsomt kan det egentlig bli når norske komikere gjør relativt hverdagslige ting? Det skal Odd-Magnus Williamson og Henrik Thodesen finne ut av i TVNorges nye humorsatsing. Med seg har de fått Linn Skåber, Else Kåss Furuseth, Espen Eckbo, Are Kalvø, Anne-Kat. Hærland, Knut Nærum blant andre.'],

    // ALT FOR NORGE:
    ['headline' => 'Ditt favorittprogram denne høsten er Alt for Norge',
    'description' => 'Dobbel Gullrute-vinner Alt for Norge er tilbake med tolv eventyrlystne norsk-amerikanere. I den sjette sesongen av realityprogrammet rekonstruerer de tungtvannsaksjonen og går på trynet i hoppbakken.'],

    // DANSKEN OG FINGEREN: BEST I ALT:
    ['headline' => 'Ditt favorittprogram denne høsten er Dansken og Fingern: Best i alt',
    'description' => 'Hvem er best til å føde av Esben «Dansken» Selvig og Thomas «Fingern» Gullestad? Utfallet av det og mange andre helt unødvendige konkurranser utgjør essensen i programmet Dansken & Fingern – best i alt.'],

    // ÅNDENES MAKT:
    ['headline' => 'Ditt favorittprogram denne høsten er Åndenes makt',
    'description' => 'I over hundre episoder har Tom Strømnæss jaktet på forklaringer på uforklarlige fenomener. Den ellevte sesongen innledes med et besøk på Dovrefjell hotell, der de ansatte plages av ting de ikke forstår. Lena Ranehag og Tom Strømnæss sjekker inn på hotellet, og for en av dem blir natten av det urolige slaget.'],

    // MONTEBELLO CAMPING:
    ['headline' => 'Ditt favorittprogram denne høsten er Montebello camping',
    'description' => 'Den familiedrevne campingplassen Montebello Camping, like ved svenskegrensa, smykker seg med slagordet «innfallsporten til Europa». Nå blir det dokusåpe av alle de fargerike feriegjestenes opplevelser. '],

    // GIFT VED FØRSTE BLIKK:
    ['headline' => 'Ditt favorittprogram denne høsten er Gift ved første blikk',
    'description' => 'Gift ved første blikk skapte stor debatt da programmet ble sendt på TVNorge i fjor. I høst er det duket for en ny sesong av den omstridte realityserien som allerede kan skilte med feiringen av ett års bryllupsdag for ett av parene.'],

    // SINNASNEKKER'N:
    ['headline' => 'Ditt favorittprogram denne høsten er Sinnasnekker’n',
    'description' => 'Gjennom årene har den folkekjære sinnasnekkeren Otto Robsahm hjulpet over hundre norske familier som har gjennomlevd oppussingsmarerittet. Sinnasnekker’n har ingen planer om å gi seg, og kjefter seg gjennom et titalls nye renoveringsprosjekter til høsten.'],

    // 71 GRADER NORD:
    ['headline' => 'Ditt favorittprogram denne høsten er 71° nord',
    'description' => 'Til høsten leder eks-alpinist Tom Stiansen sin tiende sesong av TVNorges realityflaggskip 71° nord.'],

    // PÅSKEEGG: FORBINDELSER PÅ DPLAY:
    ['headline' => 'Ditt favorittprogram denne høsten er Forbindelser på Dplay',
    'description' => 'Hei. Dette ble litt rotete og rart, så algoritmen har blitt nødt til å følge sitt eget hjerte. Valget falt derfor på programmet Forbindelser på Nett-TV-tjenesten Dplay. Hvordan var det å være kvinne i Norge i 2012? I Forbindelser får vi noen av svarene da fem vidt forskjellige kvinner filmer sin egen hverdag. For å se på Dplay trenger du abonnement. Send mail med skjermbilde av dette til XXX og fortell at du har funnet påskeegget i TVNorges valgomat så spanderer vi Nett-TV på deg i et år. '],

    // FEILMELDING:
    ['headline' => 'Feilmelding',
    'description' => 'Oops! Der skjedde det noe feil som ikke er riktig. Restart appen og prøv igjen.']
];
?>

