<?php
$localizedStrings = array(
    'START-HEADING' => 'Velkommen til TVNorges valgomat',
    'START-SHORTDESC' => 'Det er valgår i år og TVNorges valgomat kan hjelpe deg med din nest viktigste beslutning denne høsten: Hva du skal se på TV.',
    'START-BUTTON-TEXT' => 'Start valomaten',
);
?>
